package com.example.calculatordemo.controller;

import com.example.calculatordemo.bean.Record;
import com.example.calculatordemo.domain.GetDataParam;
import com.example.calculatordemo.domain.ResultBean;
import com.example.calculatordemo.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class RecordController {

    @Autowired
    private CalculatorService calculatorService;


    /**
     * 写入数据
     * @param record
     * @return
     */
    @PostMapping("/insertRecord")
    public ResultBean insertRecord(@RequestBody Record record) {
        return calculatorService.insertData(record);
    }

    /**
     * 查询数据
     * @param getDataParam
     * @return
     */
    @PostMapping("/getRecord")
    public ResultBean getRecord(@RequestBody GetDataParam getDataParam) {
        return calculatorService.getData(getDataParam);
    }
}
