package com.example.calculatordemo.domain;

/**
 * 查询数据入参
 */
public class GetDataParam {

    private int index;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
